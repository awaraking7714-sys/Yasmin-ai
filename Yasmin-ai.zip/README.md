# Yesmin AI — Female Jarvis Android Assistant

Yesmin AI is a high-tech female AI companion and smart Android assistant engineered in Kotlin with Jetpack Compose, featuring speech recognition and TTS, Gemini AI reasoning, safe phone command automation, YouTube music integration, coding assistance, and local memory.

---

## Key Features

1. **Female AI Girlfriend & Companion Personality**:
   - Speaks fluent, natural **Hindi**, **Hinglish**, and **English**.
   - Customizable nickname: Yesmin addresses you as **Jaan**, **Babu**, **Boss**, or your custom name.
   - 4 Dynamic Personality Modes:
     - 💖 **Girlfriend Mode**: Loving, affectionate, caring, emotionally intelligent, and playful.
     - ⚡ **Best Friend Mode**: Casual, fun, witty, and supportive friend (dost).
     - 🤖 **Jarvis Mode**: Crisp, concise, professional Android assistant.
     - 💻 **Dev Mode**: Architecture advice, syntax explanation, and bug fixing.
   - Respectful boundaries: Privacy-first, respects personal boundaries, never claims physical human biology.

2. **Futuristic Visual Interface**:
   - Obsidian dark canvas (`#090812`) with Electric Violet (`#8B5CF6`), Cyber Cyan (`#06B6D4`), and Neon Pink (`#EC4899`).
   - Animated **Neural Orb** core with dynamic audio waveform frequency bars responding to voice amplitude.
   - Sliding chat history drawer with copy and voice replay buttons.

3. **Android Voice Assistant Pipeline**:
   - Real-time speech recognition using Android's native `SpeechRecognizer`.
   - Natural spoken responses using Android `TextToSpeech` with female voice pitch modulation (1.15f).
   - Audio amplitude detection feeding real-time visualizer.

4. **Safe Android Phone Command Automation**:
   - **YouTube Music**: Say *"Play Arijit Singh songs"* or *"Play Hanuman Chalisa"* to open YouTube/YouTube Music directly.
   - **WhatsApp**: Launch WhatsApp directly with voice.
   - **Chrome**: Open web browser or search queries.
   - **Flashlight**: Toggle hardware LED torch with voice command (*"Flashlight on karo"*).
   - **Alarms**: Set alarms (*"Subah 6 baje ka alarm lagao"*).
   - **Camera & Calculator**: Instant voice shortcuts.

5. **Coding Assistant Screen**:
   - Multi-language generation (Kotlin, Python, Java, JavaScript, C++, HTML/CSS).
   - Monospace syntax display with copy-to-clipboard and save-snippet actions.

6. **Local Memory & Privacy**:
   - Remembers user nickname, personality mode, and approved personal notes.
   - One-tap "Clear Chat" and "Wipe All Data" options.

---

## Gemini AI Configuration

Yesmin AI works both online (with full Gemini AI reasoning) and offline (with local companion dialog and phone command support).

### Setting up Gemini API:
1. **Via AI Studio Secrets**:
   The app reads `BuildConfig.GEMINI_API_KEY` injected securely via AI Studio.
2. **Via In-App Settings**:
   Navigate to the **Settings** tab inside Yesmin AI, enter your Gemini API Key (`AIzaSy...`), select your model (`gemini-2.5-flash`), and tap **Test Gemini Connection** to verify live ping and latency.

*Security Warning*: Storing private production API keys on client devices carries extraction risks if APKs are decompiled. Keep private keys secure and do not share public APKs with unconstrained production credentials.

---

## Termux Build Workflow (Building on Android Phone)

You can build this project directly on your Android phone using Termux!

### 1. Requirements in Termux:
```bash
pkg update -y
pkg install -y openjdk-17 gradle git clang
```

### 2. Android Command Line Tools Setup in Termux:
Install Android CLI tools or use an aapt2 wrapper compatible with ARM64:
```bash
mkdir -p $HOME/android-sdk/cmdline-tools
# Set environment variables in ~/.bashrc:
export ANDROID_HOME=$HOME/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
```

### 3. Build Debug APK:
```bash
chmod +x Termux/build_termux.sh
./Termux/build_termux.sh
```

Or run directly with Gradle:
```bash
gradle :app:assembleDebug --no-daemon -Dorg.gradle.jvmargs="-Xmx1536m -XX:MaxMetaspaceSize=512m"
```

### 4. Locate and Install APK:
The output APK is generated at:
```bash
app/build/outputs/apk/debug/app-debug.apk
```
To install directly from Termux:
```bash
termux-open app/build/outputs/apk/debug/app-debug.apk
```
Or copy to your phone's Downloads directory:
```bash
cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/YesminAI.apk
```

### 5. Troubleshooting Termux Builds:
- **Out of Memory (OOM)**: Mobile RAM is limited. Pass `-Dorg.gradle.jvmargs="-Xmx1024m -XX:MaxMetaspaceSize=384m"` and disable the Gradle daemon (`--no-daemon`).
- **AAPT2 Binary Incompatibility**: Some Android architectures require an ARM64-compiled `aapt2` binary. Add `android.aapt2FromMavenOverride=/data/data/com.termux/files/usr/bin/aapt2` to `gradle.properties` if AAPT2 fails to execute.
- **Android Studio Fallback**: If building natively on phone encounters platform memory constraints, clone the repository to a computer and open in standard Android Studio (Giraffe / Iguana / Koala / Ladybug).

---

## Architecture & Tech Stack

- **Language**: Kotlin 2.0+
- **UI Framework**: Jetpack Compose (Material 3)
- **Architecture**: MVVM with Repository Pattern
- **Async & Concurrency**: Kotlin Coroutines & Flow
- **Network**: OkHttp / Retrofit with Google Gemini REST API v1beta
- **Audio & Speech**: Android SpeechRecognizer + TextToSpeech
- **Hardware Integration**: Android CameraManager (Torch/Flashlight), AlarmClock intents, Package launchers
