# Yesmin AI — Female Jarvis Android Assistant

A high-tech, futuristic female AI companion and smart Android assistant engineered in Kotlin and Jetpack Compose. Yesmin speaks natural Hindi, Hinglish, and English, featuring a glowing animated neural core, real-time voice waveform visualizations, Android device command routing (flashlight, apps, alarms), YouTube music launcher, coding assistant with syntax display, persistent local memory, and full Termux build compatibility.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and UX choices have been selected for Yesmin AI based on the project specification and default preferences:

- **Confirmed Default Persona**: Starts in **Girlfriend Mode** (warm, affectionate, playful, caring in Hindi/Hinglish, addressing the user with customizable endearing nicknames like 'Babu', 'Jaan', or custom name), with instant switching to **Best Friend**, **Professional Assistant**, or **Coding Expert**.
- **Gemini Engine & API Integration**: Dual-mode backend support:
  1. Primary zero-friction via `BuildConfig.GEMINI_API_KEY` (injected via AI Studio Secrets).
  2. In-app dedicated AI Settings screen with custom key configuration, model selector (`gemini-2.5-flash`, `gemini-1.5-flash`, etc.), temperature, max tokens, and real "Test Connection" validation (no fake green checks).
  3. Graceful offline/fallback conversational agent when API key is unconfigured or network is unavailable.
- **Visual Design Identity**: Cyberpunk/Jarvis futuristic neon aesthetic with Deep Space Onyx background (`#0A0914`), Electric Violet (`#8B5CF6`), Cyber Cyan (`#06B6D4`), and Neon Magenta (`#EC4899`) glowing accents, pulsating neural orb with interactive audio waveforms.
- **Command Safety & Device Control**: Real Android Intent execution for WhatsApp, Chrome, Camera, YouTube search, Flashlight (`CameraManager`), and Alarm scheduling (`AlarmClock`), gated with user permission checks and verified allowlists.
- **Termux & Native Build Workflow**: Self-contained build script and documented CLI instructions tailored for Termux on Android devices (OpenJDK 17, Android SDK CLI tools, aapt2/d8 compatibility) as well as standard Gradle.

---

## 1. Overview & Core Concept

- **What It Does**: Yesmin AI acts as a personal female AI assistant and companion on Android. Users interact via voice (Android `SpeechRecognizer` + `TextToSpeech` with Hindi/English locales) or text chat. Yesmin can chit-chat affectionately in Hinglish, answer complex queries using Google's Gemini models, automate daily phone tasks (opening apps, toggling flashlight, setting alarms), launch YouTube music queries, explain and generate code, take quick notes, and retain user-approved memories locally.
- **Target Audience / Persona**: Users seeking a responsive, emotionally intelligent voice companion who speaks their language (Hindi & Hinglish) while serving as a productive daily driver for phone automation, music, and software development.
- **Key Value**: Merges genuine emotional warmth and companion banter with practical Android utility and coding intelligence in an ultra-modern, battery-conscious Jetpack Compose UI.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **First Launch & Onboarding**: Warm introductory voice greeting from Yesmin in Hinglish ("*Namaste! Main hoon Yesmin, aapki personal AI assistant aur companion. Aap mujhe kis naam se bulana pasand karenge?*"). User sets their nickname and preferred personality mode.
2. **Voice Interaction Flow**: User taps the pulsating central microphone button -> Neural orb shifts from idle breath to active cyan waveform -> SpeechRecognizer listens in real-time -> User releases or stops talking -> Orb transitions to violet spinning "Thinking" state -> Gemini processes prompt -> Yesmin speaks back using Android TTS while the waveform ripples to speech cadence, appending to the interactive chat drawer.
3. **Phone Command & YouTube Flow**: User says "*Yesmin, Arijit Singh ke gaane chalao*" or "*Open WhatsApp*" -> Command router validates against allowlist -> Directly launches YouTube search intent or WhatsApp app intent with fallback to web browser -> Yesmin responds with spoken confirmation.
4. **Coding Assistant Screen**: Dedicated tab for multi-language code generation (Kotlin, Python, JS, C++), line-by-line breakdown, bug diagnosis, and one-tap copy/export.
5. **AI Brain & Memory Settings**: Manage Gemini API keys, test connection status, adjust temperature, view/edit saved facts in local memory, or clear conversation history with a single tap.

### Visual Identity & Theme
- **Theme Direction**: Neo-Futuristic Cyber-Jarvis Dark UI with glowing glassmorphism and organic pulsating animations.
- **Color Palette**:
  - `DarkBackground`: `#0A0914` (Deep obsidian/space canvas)
  - `SurfaceDark`: `#121124` (Semi-translucent dark glass card)
  - `PrimaryViolet`: `#8B5CF6` (Dominant neural core color)
  - `AccentCyan`: `#06B6D4` (Active listening and tech highlight)
  - `AccentPink`: `#EC4899` (Girlfriend mode warmth accent)
  - `TextPrimary`: `#F8FAFC` (High contrast crisp white)
  - `TextSecondary`: `#94A3B8` (Muted metallic silver)
  - `SuccessNeon`: `#10B981` (Connected status)
  - `WarningAmber`: `#F59E0B` (Permission / offline status)
- **Typography & Hierarchy**:
  - Display headers: High-tech geometric bold fonts with letter-spacing.
  - Body: Crisp, accessible modern typography with generous line height for Hindi Devanagari and Latin Hinglish readability.
- **Interactive Feedback & Motion**:
  - Circular Canvas waveform with 32 frequency bars reacting to speech/listening amplitude.
  - Smooth spring transitions between idle, listening, thinking, and speaking states.
  - Haptic feedback on microphone press and quick-action triggers.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Direct Gemini REST/SDK Repository Layer vs Cloud Functions Backend**
  - *Chosen Approach*: Isolated repository layer supporting both `BuildConfig.GEMINI_API_KEY` (injected securely at build time via AI Studio Secrets) and user-entered custom key in the settings UI.
  - *Why*: Allows standalone operation, fast local testing, and full portability when building inside Termux or Android Studio without mandatory cloud infrastructure.
  - *Trade-off*: Client-side keys require clear security disclosures in the UI regarding decompilation risks.
- **Decision 2: Native Android Speech APIs vs Cloud Audio Services**
  - *Chosen Approach*: Android `SpeechRecognizer` (`android.speech.SpeechRecognizer`) and Android `TextToSpeech` (`android.speech.tts.TextToSpeech`) configured with `hi_IN` / `en_IN` fallback.
  - *Why*: Instant response, zero audio-streaming API cost, works offline for basic command triggers, and respects device battery and privacy.
- **Decision 3: Local Storage Strategy**
  - *Chosen Approach*: Android `Room` / `SharedPreferences` for chat history, user nickname, personality preferences, and approved memories.
  - *Why*: Keeps user data strictly private on device without telemetry or third-party leaks.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Jetpack Compose UI Layer                        │
│  ┌───────────────────────┐ ┌───────────────────┐ ┌───────────────────┐ │
│  │   FuturisticHomeScreen │ │   CodingAssistant │ │    SettingsScreen │ │
│  │  - NeuralOrb Canvas    │ │  - Prompt / Code │ │  - API Key & Test │ │
│  │  - Waveform Visualizer │ │  - Syntax Card    │ │  - Persona Switch │ │
│  │  - Chat History Drawer │ │  - Language Pick  │ │  - Memory Manager │ │
│  └───────────┬───────────┘ └─────────┬─────────┘ └─────────┬─────────┘ │
└──────────────┼───────────────────────┼─────────────────────┼───────────┘
               ▼                       ▼                     ▼
┌────────────────────────────────────────────────────────────────────────┐
│                      YesminViewModel (State Holder)                    │
│   UiState: Idle | Listening | Thinking | Speaking | ActionExecuted    │
│   ChatMessages StateFlow | PersonalityState | ApiStatusState           │
└──────┬──────────────────────┬───────────────────────────────┬──────────┘
       │                      │                               │
       ▼                      ▼                               ▼
┌──────────────┐     ┌────────────────┐             ┌──────────────────┐
│ VoiceManager │     │ CommandRouter  │             │ GeminiRepository │
│ - SpeechRec  │     │ - WhatsApp/App │             │ - generateContent│
│ - TTS Engine │     │ - Flashlight   │             │ - Stream / Chat  │
│ - Audio Amp  │     │ - Alarms       │             │ - Test Connect   │
│              │     │ - YouTube Music│             │ - Custom System  │
└──────────────┘     └────────────────┘             └──────────────────┘
                              │                               │
                              ▼                               ▼
                     ┌──────────────────┐            ┌──────────────────┐
                     │ Android Hardware │            │ Google Gemini API│
                     │  & OS Intents    │            │  (Flash Models)  │
                     └──────────────────┘            └──────────────────┘
```

### Component & Package Organization
- `com.yesmin.ai`:
  - `MainActivity.kt`: Single activity entry point with edge-to-edge Compose setup, permission launchers, and bottom navigation.
  - `ui/`:
    - `screens/HomeScreen.kt`: Animated neural orb, voice waveform, microphone trigger, quick prompts.
    - `screens/ChatDrawer.kt`: Interactive conversation feed with copy and retry buttons.
    - `screens/CodingScreen.kt`: Developer assistant with syntax highlights, explanation generator, and snippet saver.
    - `screens/SettingsScreen.kt`: Gemini API key management, connection tester, personality selector, nickname editor, memory cleaner.
    - `components/NeuralOrb.kt`: Custom Canvas rendering glowing multi-ring pulse, particle dust, and dynamic audio waves.
    - `theme/`: Complete M3 futuristic color scheme, shapes, and typography.
  - `ai/`:
    - `GeminiService.kt`: Retrofit / OkHttp Gemini REST API client supporting `gemini-2.5-flash` and `gemini-1.5-flash`.
    - `PersonalityPrompts.kt`: System prompts for Girlfriend (Hinglish/Hindi warmth), Best Friend, Professional, and Coding modes.
  - `voice/`:
    - `VoiceManager.kt`: Encapsulates `SpeechRecognizer`, `RecognitionListener`, amplitude callbacks for visualizer, and `TextToSpeech` with auto language detection.
  - `commands/`:
    - `CommandRouter.kt`: Pattern matches user voice/text commands for:
      - Apps: WhatsApp, Chrome, Camera, Calculator, Settings, YouTube.
      - Device: Flashlight toggle (`CameraManager`), Alarm creation (`AlarmClock.ACTION_SET_ALARM`).
      - Music: YouTube search intent (`vnd.youtube:`) with browser fallback.
  - `data/`:
    - `MemoryRepository.kt`: Local preferences, stored user facts, and chat message history.
- `Termux/`:
  - `build_termux.sh`: Complete CLI bash script for building the APK directly in Termux using OpenJDK 17 and Android SDK build-tools.
  - `README.md`: Comprehensive setup and build guide for both Termux and Android Studio.

---

## Phase Execution Roadmap

- **Phase 1**: Architecture, dependencies, build configurations (`app/build.gradle.kts`, `AndroidManifest.xml`, permissions, strings), theme, and Main UI with animated neural core and waveform visualizer.
- **Phase 2**: Voice manager (`SpeechRecognizer` + `TextToSpeech`), Gemini API client with dual-key support and real connection test, personality engine, and memory storage.
- **Phase 3**: Safe Android Phone Command Router (WhatsApp, Chrome, Flashlight, Alarms, YouTube Music intent integration).
- **Phase 4**: Coding Assistant module (code generation, bug explanation, syntax display, clipboard copy) and utilities.
- **Phase 5**: Termux build script, README documentation, validation tests, and final verification.
