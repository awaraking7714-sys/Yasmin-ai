package com.example

import com.example.ai.PersonalityPrompts
import com.example.data.PersonalityMode
import com.example.data.UserMemory
import org.junit.Test
import org.junit.Assert.*

class ExampleUnitTest {
    @Test
    fun testGirlfriendPromptContainsNicknameAndHindiContext() {
        val prompt = PersonalityPrompts.getSystemPrompt(
            mode = PersonalityMode.GIRLFRIEND,
            nickname = "Jaan",
            memories = listOf(UserMemory(key = "Favorite Drink", fact = "Chai"))
        )
        assertTrue(prompt.contains("Jaan"))
        assertTrue(prompt.contains("Hindi and Hinglish"))
        assertTrue(prompt.contains("Favorite Drink: Chai"))
    }

    @Test
    fun testBestFriendPromptContainsFriendlySlang() {
        val prompt = PersonalityPrompts.getSystemPrompt(
            mode = PersonalityMode.BEST_FRIEND,
            nickname = "Arjun",
            memories = emptyList()
        )
        assertTrue(prompt.contains("Arjun"))
        assertTrue(prompt.contains("Dost"))
    }

    @Test
    fun testCodingExpertPromptContainsArchitectureFocus() {
        val prompt = PersonalityPrompts.getSystemPrompt(
            mode = PersonalityMode.CODING_EXPERT,
            nickname = "Dev",
            memories = emptyList()
        )
        assertTrue(prompt.contains("Kotlin"))
        assertTrue(prompt.contains("software engineer"))
    }
}
