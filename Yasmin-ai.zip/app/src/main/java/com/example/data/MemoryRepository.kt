package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import org.json.JSONArray
import org.json.JSONObject

enum class PersonalityMode(val id: String, val displayName: String, val subtitle: String) {
    GIRLFRIEND("GIRLFRIEND", "Girlfriend Mode", "प्यारी और केयरिंग (Romantic & Caring)"),
    BEST_FRIEND("BEST_FRIEND", "Best Friend Mode", "मस्त दोस्त (Casual, Fun & Supportive)"),
    PROFESSIONAL("PROFESSIONAL", "Jarvis Mode", "प्रोफेशनल असिस्टेंट (Crisp & Direct)"),
    CODING_EXPERT("CODING_EXPERT", "Dev Mode", "कोडिंग मास्टर (Architecture & Code)")
}

enum class MessageSender {
    USER, YESMIN, SYSTEM
}

data class ChatMessage(
    val id: String = System.currentTimeMillis().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionTag: String? = null,
    val isCode: Boolean = false
)

data class NoteItem(
    val id: String = System.currentTimeMillis().toString(),
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class UserMemory(
    val id: String = System.currentTimeMillis().toString(),
    val key: String,
    val fact: String,
    val createdAt: Long = System.currentTimeMillis()
)

class MemoryRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("yesmin_ai_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_NICKNAME = "user_nickname"
        private const val KEY_PERSONALITY = "personality_mode"
        private const val KEY_API_KEY = "custom_gemini_api_key"
        private const val KEY_SELECTED_MODEL = "selected_gemini_model"
        private const val KEY_NOTES = "saved_notes_json"
        private const val KEY_MEMORIES = "user_memories_json"
        private const val KEY_CHAT = "chat_history_json"
        private const val KEY_VOICE_ENABLED = "voice_tts_enabled"
        private const val KEY_LANGUAGE = "preferred_language"
    }

    fun getUserNickname(): String {
        return prefs.getString(KEY_NICKNAME, "Jaan") ?: "Jaan"
    }

    fun setUserNickname(nickname: String) {
        prefs.edit().putString(KEY_NICKNAME, nickname.trim().ifEmpty { "Jaan" }).apply()
    }

    fun getPersonalityMode(): PersonalityMode {
        val name = prefs.getString(KEY_PERSONALITY, PersonalityMode.GIRLFRIEND.name)
        return try {
            PersonalityMode.valueOf(name ?: PersonalityMode.GIRLFRIEND.name)
        } catch (_: Exception) {
            PersonalityMode.GIRLFRIEND
        }
    }

    fun setPersonalityMode(mode: PersonalityMode) {
        prefs.edit().putString(KEY_PERSONALITY, mode.name).apply()
    }

    fun getApiKey(): String {
        val customKey = prefs.getString(KEY_API_KEY, "") ?: ""
        if (customKey.isNotBlank()) return customKey
        return try {
            val buildKey = BuildConfig.GEMINI_API_KEY
            if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") buildKey else ""
        } catch (_: Exception) {
            ""
        }
    }

    fun getCustomApiKey(): String {
        return prefs.getString(KEY_API_KEY, "") ?: ""
    }

    fun setCustomApiKey(key: String) {
        prefs.edit().putString(KEY_API_KEY, key.trim()).apply()
    }

    fun getSelectedModel(): String {
        return prefs.getString(KEY_SELECTED_MODEL, "gemini-2.5-flash") ?: "gemini-2.5-flash"
    }

    fun setSelectedModel(model: String) {
        prefs.edit().putString(KEY_SELECTED_MODEL, model).apply()
    }

    fun isVoiceTtsEnabled(): Boolean {
        return prefs.getBoolean(KEY_VOICE_ENABLED, true)
    }

    fun setVoiceTtsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_VOICE_ENABLED, enabled).apply()
    }

    fun getPreferredLanguage(): String {
        return prefs.getString(KEY_LANGUAGE, "hi") ?: "hi"
    }

    fun setPreferredLanguage(lang: String) {
        prefs.edit().putString(KEY_LANGUAGE, lang).apply()
    }

    fun getNotes(): List<NoteItem> {
        val jsonStr = prefs.getString(KEY_NOTES, "[]") ?: "[]"
        val list = mutableListOf<NoteItem>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    NoteItem(
                        id = obj.optString("id", System.currentTimeMillis().toString()),
                        title = obj.optString("title", "Note"),
                        content = obj.optString("content", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun addNote(title: String, content: String): NoteItem {
        val current = getNotes().toMutableList()
        val newNote = NoteItem(
            id = System.currentTimeMillis().toString(),
            title = title,
            content = content,
            timestamp = System.currentTimeMillis()
        )
        current.add(0, newNote)
        saveNotes(current)
        return newNote
    }

    fun deleteNote(noteId: String) {
        val updated = getNotes().filter { it.id != noteId }
        saveNotes(updated)
    }

    private fun saveNotes(notes: List<NoteItem>) {
        val array = JSONArray()
        for (n in notes) {
            val obj = JSONObject()
            obj.put("id", n.id)
            obj.put("title", n.title)
            obj.put("content", n.content)
            obj.put("timestamp", n.timestamp)
            array.put(obj)
        }
        prefs.edit().putString(KEY_NOTES, array.toString()).apply()
    }

    fun getMemories(): List<UserMemory> {
        val jsonStr = prefs.getString(KEY_MEMORIES, "[]") ?: "[]"
        val list = mutableListOf<UserMemory>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    UserMemory(
                        id = obj.optString("id", System.currentTimeMillis().toString()),
                        key = obj.optString("key", "Memory"),
                        fact = obj.optString("fact", ""),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun addMemory(key: String, fact: String): UserMemory {
        val current = getMemories().toMutableList()
        val mem = UserMemory(
            id = System.currentTimeMillis().toString(),
            key = key,
            fact = fact,
            createdAt = System.currentTimeMillis()
        )
        current.add(mem)
        saveMemories(current)
        return mem
    }

    fun deleteMemory(id: String) {
        val updated = getMemories().filter { it.id != id }
        saveMemories(updated)
    }

    fun clearMemories() {
        prefs.edit().remove(KEY_MEMORIES).apply()
    }

    private fun saveMemories(memories: List<UserMemory>) {
        val array = JSONArray()
        for (m in memories) {
            val obj = JSONObject()
            obj.put("id", m.id)
            obj.put("key", m.key)
            obj.put("fact", m.fact)
            obj.put("createdAt", m.createdAt)
            array.put(obj)
        }
        prefs.edit().putString(KEY_MEMORIES, array.toString()).apply()
    }

    fun getChatHistory(): List<ChatMessage> {
        val jsonStr = prefs.getString(KEY_CHAT, "[]") ?: "[]"
        val list = mutableListOf<ChatMessage>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    ChatMessage(
                        id = obj.optString("id", System.currentTimeMillis().toString()),
                        sender = MessageSender.valueOf(obj.optString("sender", MessageSender.YESMIN.name)),
                        text = obj.optString("text", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        actionTag = if (obj.has("actionTag") && !obj.isNull("actionTag")) obj.getString("actionTag") else null,
                        isCode = obj.optBoolean("isCode", false)
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun saveChatMessage(msg: ChatMessage) {
        val list = getChatHistory().toMutableList()
        list.add(msg)
        val trimmed = if (list.size > 100) list.takeLast(100) else list
        val array = JSONArray()
        for (m in trimmed) {
            val obj = JSONObject()
            obj.put("id", m.id)
            obj.put("sender", m.sender.name)
            obj.put("text", m.text)
            obj.put("timestamp", m.timestamp)
            if (m.actionTag != null) obj.put("actionTag", m.actionTag)
            obj.put("isCode", m.isCode)
            array.put(obj)
        }
        prefs.edit().putString(KEY_CHAT, array.toString()).apply()
    }

    fun clearChatHistory() {
        prefs.edit().remove(KEY_CHAT).apply()
    }

    fun wipeAllUserData() {
        prefs.edit().clear().apply()
    }
}
