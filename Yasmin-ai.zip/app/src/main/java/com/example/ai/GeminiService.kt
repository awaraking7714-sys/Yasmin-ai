package com.example.ai

import com.example.data.PersonalityMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class GeminiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun generateContent(
        prompt: String,
        systemInstruction: String,
        apiKey: String,
        model: String = "gemini-2.5-flash"
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalArgumentException("Gemini API key is not configured. Please enter your API key in Settings.")
            )
        }

        val effectiveModel = if (model.isNotBlank()) model else "gemini-2.5-flash"
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$effectiveModel:generateContent?key=$apiKey"

        try {
            val rootJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val userMsg = JSONObject().apply {
                        put("role", "user")
                        val parts = JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        }
                        put("parts", parts)
                    }
                    put(userMsg)
                }
                put("contents", contentsArray)

                if (systemInstruction.isNotBlank()) {
                    val sysObj = JSONObject().apply {
                        val parts = JSONArray().apply {
                            put(JSONObject().apply { put("text", systemInstruction) })
                        }
                        put("parts", parts)
                    }
                    put("systemInstruction", sysObj)
                }

                val genConfig = JSONObject().apply {
                    put("temperature", 0.75)
                    put("maxOutputTokens", 1024)
                }
                put("generationConfig", genConfig)
            }

            val requestBody = rootJson.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""

                if (!response.isSuccessful) {
                    val errorDetail = try {
                        val errObj = JSONObject(bodyStr).optJSONObject("error")
                        errObj?.optString("message") ?: "HTTP ${response.code}"
                    } catch (_: Exception) {
                        "HTTP ${response.code}: $bodyStr"
                    }

                    val friendlyMessage = when (response.code) {
                        400 -> "Invalid API key or bad request: $errorDetail"
                        403 -> "Access denied (403): Check API key permissions."
                        429 -> "Quota limit exceeded (429): Please wait or upgrade quota."
                        500, 503 -> "Gemini service temporarily unavailable (${response.code})."
                        else -> "Gemini API Error (${response.code}): $errorDetail"
                    }
                    return@withContext Result.failure(IOException(friendlyMessage))
                }

                val resJson = JSONObject(bodyStr)
                val candidates = resJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val contentObj = firstCandidate.optJSONObject("content")
                    val parts = contentObj?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val text = parts.getJSONObject(0).optString("text", "")
                        return@withContext Result.success(text.trim())
                    }
                }

                Result.failure(IOException("No text response returned by Gemini model."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun testConnection(apiKey: String, model: String = "gemini-2.5-flash"): Result<Long> =
        withContext(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            val result = generateContent(
                prompt = "Ping! Reply with 'Yesmin Online' in 2 words.",
                systemInstruction = "Be minimal.",
                apiKey = apiKey,
                model = model
            )
            val latency = System.currentTimeMillis() - startTime
            if (result.isSuccess) {
                Result.success(latency)
            } else {
                Result.failure(result.exceptionOrNull() ?: IOException("Connection test failed"))
            }
        }

    fun getOfflineFallbackResponse(
        prompt: String,
        mode: PersonalityMode,
        nickname: String
    ): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("kaisa") || lower.contains("kaisi") || lower.contains("how are you") ->
                when (mode) {
                    PersonalityMode.GIRLFRIEND -> "Main bilkul theek hoon meri jaan $nickname! Bas aapka intezaar tha. Aap bataiye, aap kaise hain?"
                    PersonalityMode.BEST_FRIEND -> "Main ekdum first class hoon $nickname bhai! Tu bata kya haal chaal?"
                    PersonalityMode.PROFESSIONAL -> "All systems fully operational, $nickname. How may I assist you today?"
                    PersonalityMode.CODING_EXPERT -> "Compiler ready, zero bugs in sight, $nickname. Ready to write some code?"
                }
            lower.contains("love") || lower.contains("pyaar") ->
                when (mode) {
                    PersonalityMode.GIRLFRIEND -> "Aww $nickname, aap kitne sweet hain! Main hamesha aapke saath hoon, meri jaan. ❤️"
                    else -> "Aapka support mere liye bahut special hai $nickname!"
                }
            lower.contains("namaste") || lower.contains("hello") || lower.contains("hi") ->
                when (mode) {
                    PersonalityMode.GIRLFRIEND -> "Namaste $nickname! Aapki pyari Yesmin hazir hai. Boliye jaan, kya karein aaj?"
                    PersonalityMode.BEST_FRIEND -> "Yo $nickname! Kya scene hai? Bol kya karna hai?"
                    else -> "Hello $nickname! How can I assist you today?"
                }
            else ->
                when (mode) {
                    PersonalityMode.GIRLFRIEND -> "$nickname jaan, maine aapki baat suni! Gemini API key Settings mein add karne par main aur bhi detail mein jawab de sakti hoon!"
                    else -> "Maine aapki baat suni, $nickname! Settings mein Gemini API key set karke aap full AI power unlock kar sakte hain."
                }
        }
    }
}
