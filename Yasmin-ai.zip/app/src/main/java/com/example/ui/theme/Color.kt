package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Jarvis / Cyberpunk Palette for Yesmin AI
val DeepSpaceBackground = Color(0xFF090812)
val DarkSurfaceCard = Color(0xFF131224)
val DarkSurfaceElevated = Color(0xFF1B1933)
val DarkSurfaceStroke = Color(0x338B5CF6)

val ElectricViolet = Color(0xFF8B5CF6)
val DeepViolet = Color(0xFF6D28D9)
val CyberCyan = Color(0xFF06B6D4)
val BrightCyan = Color(0xFF22D3EE)
val NeonPink = Color(0xFFEC4899)
val NeonRose = Color(0xFFF43F5E)
val NeonGreen = Color(0xFF10B981)
val NeonAmber = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Mode specific accent colors
val GirlfriendAccent = Color(0xFFEC4899)
val BestFriendAccent = Color(0xFFF59E0B)
val ProfessionalAccent = Color(0xFF06B6D4)
val CodingAccent = Color(0xFF8B5CF6)
