package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.GeminiService
import com.example.ai.PersonalityPrompts
import com.example.commands.CommandRouter
import com.example.data.ChatMessage
import com.example.data.MemoryRepository
import com.example.data.MessageSender
import com.example.data.PersonalityMode
import com.example.ui.components.NeuralOrb
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DeepSpaceBackground
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.voice.VoiceManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    memoryRepository: MemoryRepository,
    geminiService: GeminiService,
    voiceManager: VoiceManager,
    commandRouter: CommandRouter,
    onRequestRecordPermission: () -> Unit,
    hasRecordPermission: Boolean,
    onNavigateToCoding: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isListening by remember { mutableStateOf(false) }
    var isThinking by remember { mutableStateOf(false) }
    var isSpeaking by remember { mutableStateOf(false) }
    var rmsLevel by remember { mutableFloatStateOf(0.1f) }
    var statusText by remember { mutableStateOf("Tap the microphone or say 'Yesmin'...") }
    var textInput by remember { mutableStateOf("") }
    var chatMessages by remember { mutableStateOf(memoryRepository.getChatHistory()) }
    var showChatSheet by remember { mutableStateOf(false) }

    val currentMode = memoryRepository.getPersonalityMode()
    val nickname = memoryRepository.getUserNickname()
    val apiKey = memoryRepository.getApiKey()
    val isTtsEnabled = memoryRepository.isVoiceTtsEnabled()

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    fun handleUserInput(rawText: String) {
        val text = rawText.trim()
        if (text.isBlank()) return

        val userMsg = ChatMessage(sender = MessageSender.USER, text = text)
        memoryRepository.saveChatMessage(userMsg)
        chatMessages = memoryRepository.getChatHistory()

        // 1. Check for local phone command
        val cmdResult = commandRouter.processCommand(text)
        if (cmdResult.isCommand) {
            val responseMsg = ChatMessage(
                sender = MessageSender.YESMIN,
                text = cmdResult.feedbackMessage,
                actionTag = cmdResult.actionName
            )
            memoryRepository.saveChatMessage(responseMsg)
            chatMessages = memoryRepository.getChatHistory()
            statusText = cmdResult.feedbackMessage

            if (isTtsEnabled) {
                isSpeaking = true
                voiceManager.speak(cmdResult.feedbackMessage, memoryRepository.getPreferredLanguage()) {
                    isSpeaking = false
                }
            }
            return
        }

        // 2. Query Gemini API Brain or Fallback
        isThinking = true
        statusText = "Yesmin is thinking..."

        scope.launch {
            val currentApiKey = memoryRepository.getApiKey()
            val memories = memoryRepository.getMemories()
            val sysInstruction = PersonalityPrompts.getSystemPrompt(currentMode, nickname, memories)

            if (currentApiKey.isNotBlank()) {
                val result = geminiService.generateContent(
                    prompt = text,
                    systemInstruction = sysInstruction,
                    apiKey = currentApiKey,
                    model = memoryRepository.getSelectedModel()
                )

                isThinking = false
                if (result.isSuccess) {
                    val reply = result.getOrNull() ?: ""
                    val botMsg = ChatMessage(sender = MessageSender.YESMIN, text = reply)
                    memoryRepository.saveChatMessage(botMsg)
                    chatMessages = memoryRepository.getChatHistory()
                    statusText = reply

                    if (isTtsEnabled) {
                        isSpeaking = true
                        voiceManager.speak(reply, memoryRepository.getPreferredLanguage()) {
                            isSpeaking = false
                        }
                    }
                } else {
                    val errorMsg = result.exceptionOrNull()?.message ?: "Error connecting to Gemini"
                    val fallbackReply = geminiService.getOfflineFallbackResponse(text, currentMode, nickname)
                    val botMsg = ChatMessage(
                        sender = MessageSender.YESMIN,
                        text = "$fallbackReply\n\n(Gemini Info: $errorMsg)"
                    )
                    memoryRepository.saveChatMessage(botMsg)
                    chatMessages = memoryRepository.getChatHistory()
                    statusText = fallbackReply

                    if (isTtsEnabled) {
                        isSpeaking = true
                        voiceManager.speak(fallbackReply, memoryRepository.getPreferredLanguage()) {
                            isSpeaking = false
                        }
                    }
                }
            } else {
                isThinking = false
                val fallbackReply = geminiService.getOfflineFallbackResponse(text, currentMode, nickname)
                val botMsg = ChatMessage(sender = MessageSender.YESMIN, text = fallbackReply)
                memoryRepository.saveChatMessage(botMsg)
                chatMessages = memoryRepository.getChatHistory()
                statusText = fallbackReply

                if (isTtsEnabled) {
                    isSpeaking = true
                    voiceManager.speak(fallbackReply, memoryRepository.getPreferredLanguage()) {
                        isSpeaking = false
                    }
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        DeepSpaceBackground,
                        Color(0xFF0F0D20),
                        DeepSpaceBackground
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (apiKey.isNotBlank()) NeonGreen else Color(0xFFF59E0B))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "YESMIN AI",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp,
                            color = Color.White
                        )
                    }
                    Text(
                        text = "Female Jarvis Assistant",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Persona mode pill
                    SuggestionChip(
                        onClick = onNavigateToSettings,
                        label = {
                            Text(
                                text = when (currentMode) {
                                    PersonalityMode.GIRLFRIEND -> "💖 Girlfriend"
                                    PersonalityMode.BEST_FRIEND -> "⚡ Best Friend"
                                    PersonalityMode.PROFESSIONAL -> "🤖 Jarvis"
                                    PersonalityMode.CODING_EXPERT -> "💻 Dev Mode"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = DarkSurfaceElevated,
                            labelColor = when (currentMode) {
                                PersonalityMode.GIRLFRIEND -> NeonPink
                                PersonalityMode.BEST_FRIEND -> Color(0xFFF59E0B)
                                PersonalityMode.PROFESSIONAL -> CyberCyan
                                PersonalityMode.CODING_EXPERT -> ElectricViolet
                            }
                        ),
                        border = SuggestionChipDefaults.suggestionChipBorder(
                            enabled = true,
                            borderColor = DarkSurfaceElevated
                        )
                    )

                    Spacer(modifier = Modifier.width(4.dp))

                    // TTS audio mute toggle
                    IconButton(
                        onClick = {
                            val newState = !isTtsEnabled
                            memoryRepository.setVoiceTtsEnabled(newState)
                            if (!newState) voiceManager.stopSpeaking()
                        }
                    ) {
                        Icon(
                            imageVector = if (isTtsEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                            contentDescription = "Toggle TTS Voice",
                            tint = if (isTtsEnabled) BrightCyan else Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // View Conversation Feed button
                    IconButton(
                        onClick = { showChatSheet = true },
                        modifier = Modifier.testTag("open_chat_drawer")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = "Chat Feed",
                            tint = ElectricViolet,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            // Connection Status Pill
            if (apiKey.isBlank()) {
                Card(
                    onClick = onNavigateToSettings,
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF261D10)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFFBBF24),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Set Gemini API Key in Settings to unlock full reasoning",
                            fontSize = 11.sp,
                            color = Color(0xFFFDE68A)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.15f))

            // Central Glowing Neural Core
            NeuralOrb(
                isListening = isListening,
                isThinking = isThinking,
                isSpeaking = isSpeaking,
                rmsLevel = rmsLevel,
                mode = currentMode,
                onClick = {
                    if (isSpeaking) {
                        voiceManager.stopSpeaking()
                        isSpeaking = false
                    } else if (!isListening) {
                        if (!hasRecordPermission) {
                            onRequestRecordPermission()
                        } else {
                            isListening = true
                            statusText = "Listening to $nickname..."
                            voiceManager.startListening(
                                language = memoryRepository.getPreferredLanguage(),
                                onRmsChanged = { level -> rmsLevel = level },
                                onResult = { text ->
                                    isListening = false
                                    handleUserInput(text)
                                },
                                onError = { err ->
                                    isListening = false
                                    statusText = err
                                    Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    } else {
                        voiceManager.stopListening()
                        isListening = false
                        statusText = "Listening paused."
                    }
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Dynamic Assistant Status Speech Text
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated.copy(alpha = 0.8f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }

            Spacer(modifier = Modifier.weight(0.2f))

            // Quick Prompt Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val prompts = listOf(
                    "Play Romantic Songs 🎵",
                    "Open WhatsApp 💬",
                    "Turn on Flashlight 💡",
                    "Set 6 AM Alarm ⏰",
                    "Explain Kotlin Flow 💻",
                    "Aap kaise ho Yesmin? ❤️"
                )
                prompts.forEach { chipText ->
                    Button(
                        onClick = {
                            val cleanPrompt = chipText.replace(Regex("[🎵💬💡⏰💻❤️]"), "").trim()
                            handleUserInput(cleanPrompt)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text(chipText, fontSize = 12.sp, color = BrightCyan)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Bottom Input Controls: Mic FAB + Text Field
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text("Ask Yesmin in Hindi or English...") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_text_input"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricViolet,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    trailingIcon = {
                        if (textInput.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    handleUserInput(textInput)
                                    textInput = ""
                                },
                                modifier = Modifier.testTag("home_send_button")
                            ) {
                                Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = BrightCyan)
                            }
                        }
                    }
                )

                Spacer(modifier = Modifier.width(10.dp))

                FloatingActionButton(
                    onClick = {
                        if (isListening) {
                            voiceManager.stopListening()
                            isListening = false
                            statusText = "Listening stopped."
                        } else {
                            if (!hasRecordPermission) {
                                onRequestRecordPermission()
                            } else {
                                isListening = true
                                statusText = "Listening to $nickname..."
                                voiceManager.startListening(
                                    language = memoryRepository.getPreferredLanguage(),
                                    onRmsChanged = { level -> rmsLevel = level },
                                    onResult = { speech ->
                                        isListening = false
                                        handleUserInput(speech)
                                    },
                                    onError = { err ->
                                        isListening = false
                                        statusText = err
                                        Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                    },
                    containerColor = if (isListening) NeonPink else ElectricViolet,
                    contentColor = Color.White,
                    modifier = Modifier
                        .size(56.dp)
                        .testTag("home_mic_fab")
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Voice Input"
                    )
                }
            }
        }

        // Slide-up Conversation Drawer
        if (showChatSheet) {
            ModalBottomSheet(
                onDismissRequest = { showChatSheet = false },
                sheetState = sheetState,
                containerColor = DarkSurfaceElevated,
                dragHandle = { BottomSheetDefaults.DragHandle(color = CyberCyan) }
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(500.dp)
                ) {
                    ChatHistoryFeed(
                        messages = chatMessages,
                        onSpeakMessage = { text ->
                            voiceManager.speak(text, memoryRepository.getPreferredLanguage())
                        },
                        onClearChat = {
                            memoryRepository.clearChatHistory()
                            chatMessages = emptyList()
                        }
                    )
                }
            }
        }
    }
}
