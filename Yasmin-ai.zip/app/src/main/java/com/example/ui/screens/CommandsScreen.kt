package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.commands.CommandRouter
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommandsScreen(
    commandRouter: CommandRouter
) {
    val context = LocalContext.current
    var isTorchEnabled by remember { mutableStateOf(commandRouter.isTorchOn) }
    var songQuery by remember { mutableStateOf("Arijit Singh romantic songs") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Phone Commands", fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Safe Device Actions",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BrightCyan
            )

            // Flashlight card
            CommandActionCard(
                icon = Icons.Default.FlashlightOn,
                iconTint = Color(0xFFFBBF24),
                title = "Flashlight / Torch",
                subtitle = "Toggle hardware camera LED flash",
                actionContent = {
                    Switch(
                        checked = isTorchEnabled,
                        onCheckedChange = { enabled ->
                            val success = commandRouter.toggleFlashlight(enabled)
                            if (success) {
                                isTorchEnabled = enabled
                            } else {
                                Toast.makeText(context, "Flashlight unavailable", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ElectricViolet
                        ),
                        modifier = Modifier.testTag("flashlight_switch")
                    )
                }
            )

            // YouTube Music Assistant Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("youtube_command_card"),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = NeonPink,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "YouTube Music Player",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                    }
                    Text(
                        text = "Launches YouTube app or mobile web search for songs",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    OutlinedTextField(
                        value = songQuery,
                        onValueChange = { songQuery = it },
                        label = { Text("Song or Artist") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    )

                    Button(
                        onClick = {
                            commandRouter.openYouTubeSearch(songQuery)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Play on YouTube")
                    }
                }
            }

            // Quick App Launchers Grid
            Text(
                text = "App Launchers",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BrightCyan
            )

            CommandActionCard(
                icon = Icons.Default.Chat,
                iconTint = NeonGreen,
                title = "WhatsApp",
                subtitle = "Voice: 'Open WhatsApp' / 'WhatsApp kholo'",
                actionContent = {
                    Button(
                        onClick = {
                            val ok = commandRouter.launchAppByPackage("com.whatsapp") ||
                                    commandRouter.launchAppByPackage("com.whatsapp.w4b") ||
                                    commandRouter.openUrlInBrowser("https://api.whatsapp.com/")
                            if (!ok) Toast.makeText(context, "WhatsApp not installed", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen)
                    ) {
                        Text("Open", color = Color.Black)
                    }
                }
            )

            CommandActionCard(
                icon = Icons.Default.Language,
                iconTint = BrightCyan,
                title = "Google Chrome",
                subtitle = "Voice: 'Open Chrome' / 'Browser kholo'",
                actionContent = {
                    Button(
                        onClick = {
                            commandRouter.launchAppByPackage("com.android.chrome") ||
                                    commandRouter.openUrlInBrowser("https://www.google.com")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrightCyan)
                    ) {
                        Text("Open", color = Color.Black)
                    }
                }
            )

            CommandActionCard(
                icon = Icons.Default.PhotoCamera,
                iconTint = ElectricViolet,
                title = "Camera",
                subtitle = "Voice: 'Open Camera' / 'Camera kholo'",
                actionContent = {
                    Button(
                        onClick = {
                            val res = commandRouter.processCommand("open camera")
                            Toast.makeText(context, res.feedbackMessage, Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
                    ) {
                        Text("Open")
                    }
                }
            )

            CommandActionCard(
                icon = Icons.Default.Calculate,
                iconTint = Color(0xFFF59E0B),
                title = "Calculator",
                subtitle = "Voice: 'Open Calculator'",
                actionContent = {
                    Button(
                        onClick = {
                            val res = commandRouter.processCommand("open calculator")
                            Toast.makeText(context, res.feedbackMessage, Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B))
                    ) {
                        Text("Open", color = Color.Black)
                    }
                }
            )

            CommandActionCard(
                icon = Icons.Default.Alarm,
                iconTint = NeonPink,
                title = "Alarm Clock",
                subtitle = "Voice: 'Subah 6 baje ka alarm lagao'",
                actionContent = {
                    Button(
                        onClick = {
                            commandRouter.processCommand("set alarm for 6 am")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPink)
                    ) {
                        Text("Set 6 AM")
                    }
                }
            )

            CommandActionCard(
                icon = Icons.Default.Settings,
                iconTint = Color.Gray,
                title = "Device Settings",
                subtitle = "Voice: 'Open Settings'",
                actionContent = {
                    Button(
                        onClick = {
                            commandRouter.processCommand("open settings")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated)
                    ) {
                        Text("Open", color = Color.White)
                    }
                }
            )
        }
    }
}

@Composable
fun CommandActionCard(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    actionContent: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            actionContent()
        }
    }
}
