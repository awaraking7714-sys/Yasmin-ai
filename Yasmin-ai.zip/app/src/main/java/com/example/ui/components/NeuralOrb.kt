package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.example.data.PersonalityMode
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonPink
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun NeuralOrb(
    isListening: Boolean,
    isThinking: Boolean,
    isSpeaking: Boolean,
    rmsLevel: Float,
    mode: PersonalityMode,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "NeuralOrbAnimation")

    // Rotation for outer HUD rings
    val rotationOuter by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotationOuter"
    )

    val rotationInner by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotationInner"
    )

    // Breathing pulse for core
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isListening) 600 else if (isThinking) 450 else 1800,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val primaryColor = when (mode) {
        PersonalityMode.GIRLFRIEND -> NeonPink
        PersonalityMode.BEST_FRIEND -> Color(0xFFF59E0B)
        PersonalityMode.PROFESSIONAL -> CyberCyan
        PersonalityMode.CODING_EXPERT -> ElectricViolet
    }

    val secondaryColor = if (mode == PersonalityMode.GIRLFRIEND) ElectricViolet else CyberCyan

    Box(
        modifier = modifier
            .size(240.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = 120.dp),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = size.minDimension / 2f * 0.72f

            // Dynamic amplitude expansion
            val activeBoost = if (isListening || isSpeaking) (rmsLevel * 25f) else 0f
            val dynamicRadius = (baseRadius * pulseScale) + activeBoost

            // 1. Ambient Background Halo Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = if (isListening) 0.45f else 0.25f),
                        secondaryColor.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = dynamicRadius * 1.5f
                ),
                radius = dynamicRadius * 1.5f,
                center = center
            )

            // 2. Outer Rotating Segmented Cyber Ring
            rotate(rotationOuter, pivot = center) {
                drawCircle(
                    color = secondaryColor.copy(alpha = 0.35f),
                    radius = baseRadius * 1.15f,
                    center = center,
                    style = Stroke(
                        width = 2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 16f, 8f, 16f), 0f)
                    )
                )

                // Outer accent nodes
                for (i in 0 until 4) {
                    val angle = (i * 90.0) * (PI / 180.0)
                    val nodeX = center.x + (baseRadius * 1.15f * cos(angle)).toFloat()
                    val nodeY = center.y + (baseRadius * 1.15f * sin(angle)).toFloat()
                    drawCircle(
                        color = BrightCyan,
                        radius = 3.dp.toPx(),
                        center = Offset(nodeX, nodeY)
                    )
                }
            }

            // 3. Counter-rotating Inner HUD Ring
            rotate(rotationInner, pivot = center) {
                drawCircle(
                    color = primaryColor.copy(alpha = 0.5f),
                    radius = baseRadius * 0.95f,
                    center = center,
                    style = Stroke(
                        width = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(40f, 20f), 0f)
                    )
                )
            }

            // 4. Circular Waveform / Frequency Bars
            val barCount = 32
            val barBaseRadius = baseRadius * 0.88f
            for (i in 0 until barCount) {
                val angle = (i.toDouble() / barCount) * 2.0 * PI
                val cosA = cos(angle).toFloat()
                val sinA = sin(angle).toFloat()

                val waveFactor = if (isListening || isSpeaking) {
                    val pseudoFreq = sin(i * 0.8f + (rotationOuter * 0.05f))
                    (0.3f + (rmsLevel * 0.7f) * (0.5f + 0.5f * pseudoFreq.toFloat()))
                } else {
                    0.15f + 0.08f * sin(i * 0.5f + (rotationOuter * 0.02f)).toFloat()
                }

                val barLength = (16.dp.toPx() * waveFactor) + if (isThinking) 10f else 0f
                val start = Offset(center.x + barBaseRadius * cosA, center.y + barBaseRadius * sinA)
                val end = Offset(center.x + (barBaseRadius + barLength) * cosA, center.y + (barBaseRadius + barLength) * sinA)

                val barColor = if (i % 2 == 0) primaryColor else BrightCyan
                drawLine(
                    color = barColor.copy(alpha = 0.85f),
                    start = start,
                    end = end,
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 5. Dense Energy Core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White,
                        BrightCyan,
                        primaryColor,
                        secondaryColor.copy(alpha = 0.6f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = dynamicRadius * 0.55f
                ),
                radius = dynamicRadius * 0.55f,
                center = center
            )

            // 6. Central Yesmin 'Y' Neural Glyph
            val glyphSize = 22.dp.toPx()
            drawLine(
                color = Color.White,
                start = Offset(center.x - glyphSize * 0.5f, center.y - glyphSize * 0.5f),
                end = Offset(center.x, center.y),
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color.White,
                start = Offset(center.x + glyphSize * 0.5f, center.y - glyphSize * 0.5f),
                end = Offset(center.x, center.y),
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color.White,
                start = Offset(center.x, center.y),
                end = Offset(center.x, center.y + glyphSize * 0.6f),
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}
