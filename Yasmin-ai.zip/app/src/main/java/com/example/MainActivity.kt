package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.NoteAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.core.content.ContextCompat
import com.example.ai.GeminiService
import com.example.commands.CommandRouter
import com.example.data.MemoryRepository
import com.example.ui.screens.CodingAssistantScreen
import com.example.ui.screens.CommandsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NotesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.MyApplicationTheme
import com.example.voice.VoiceManager

enum class AppScreen(val title: String) {
    HOME("Home"),
    CODING("Coding"),
    COMMANDS("Commands"),
    NOTES("Notes"),
    SETTINGS("Settings")
}

class MainActivity : ComponentActivity() {
    private lateinit var memoryRepository: MemoryRepository
    private lateinit var voiceManager: VoiceManager
    private lateinit var commandRouter: CommandRouter
    private val geminiService = GeminiService()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        memoryRepository = MemoryRepository(this)
        voiceManager = VoiceManager(this)
        commandRouter = CommandRouter(this, memoryRepository)

        voiceManager.initialize {
            // TTS Ready
        }

        setContent {
            MyApplicationTheme {
                var currentScreen by remember { mutableStateOf(AppScreen.HOME) }
                var hasAudioPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    hasAudioPermission = isGranted
                    if (!isGranted) {
                        Toast.makeText(
                            this,
                            "Microphone permission is needed for voice conversations with Yesmin.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.navigationBarsPadding(),
                            containerColor = DarkSurfaceElevated
                        ) {
                            NavigationBarItem(
                                selected = currentScreen == AppScreen.HOME,
                                onClick = { currentScreen = AppScreen.HOME },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Yesmin") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ElectricViolet,
                                    selectedTextColor = ElectricViolet,
                                    indicatorColor = DarkSurfaceElevated
                                ),
                                modifier = Modifier.testTag("nav_home")
                            )

                            NavigationBarItem(
                                selected = currentScreen == AppScreen.CODING,
                                onClick = { currentScreen = AppScreen.CODING },
                                icon = { Icon(Icons.Default.Code, contentDescription = "Coding") },
                                label = { Text("Code") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ElectricViolet,
                                    selectedTextColor = ElectricViolet,
                                    indicatorColor = DarkSurfaceElevated
                                ),
                                modifier = Modifier.testTag("nav_coding")
                            )

                            NavigationBarItem(
                                selected = currentScreen == AppScreen.COMMANDS,
                                onClick = { currentScreen = AppScreen.COMMANDS },
                                icon = { Icon(Icons.Default.Terminal, contentDescription = "Commands") },
                                label = { Text("Actions") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = DarkSurfaceElevated
                                ),
                                modifier = Modifier.testTag("nav_commands")
                            )

                            NavigationBarItem(
                                selected = currentScreen == AppScreen.NOTES,
                                onClick = { currentScreen = AppScreen.NOTES },
                                icon = { Icon(Icons.Default.NoteAlt, contentDescription = "Notes") },
                                label = { Text("Notes") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = BrightCyan,
                                    selectedTextColor = BrightCyan,
                                    indicatorColor = DarkSurfaceElevated
                                ),
                                modifier = Modifier.testTag("nav_notes")
                            )

                            NavigationBarItem(
                                selected = currentScreen == AppScreen.SETTINGS,
                                onClick = { currentScreen = AppScreen.SETTINGS },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Settings") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ElectricViolet,
                                    selectedTextColor = ElectricViolet,
                                    indicatorColor = DarkSurfaceElevated
                                ),
                                modifier = Modifier.testTag("nav_settings")
                            )
                        }
                    }
                ) { innerPadding ->
                    androidx.compose.foundation.layout.Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentScreen) {
                            AppScreen.HOME -> HomeScreen(
                                memoryRepository = memoryRepository,
                                geminiService = geminiService,
                                voiceManager = voiceManager,
                                commandRouter = commandRouter,
                                onRequestRecordPermission = {
                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                },
                                hasRecordPermission = hasAudioPermission,
                                onNavigateToCoding = { currentScreen = AppScreen.CODING },
                                onNavigateToSettings = { currentScreen = AppScreen.SETTINGS }
                            )

                            AppScreen.CODING -> CodingAssistantScreen(
                                memoryRepository = memoryRepository,
                                geminiService = geminiService
                            )

                            AppScreen.COMMANDS -> CommandsScreen(
                                commandRouter = commandRouter
                            )

                            AppScreen.NOTES -> NotesScreen(
                                memoryRepository = memoryRepository
                            )

                            AppScreen.SETTINGS -> SettingsScreen(
                                memoryRepository = memoryRepository,
                                geminiService = geminiService,
                                onDataCleared = {
                                    // Refresh view states
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.shutdown()
    }
}
