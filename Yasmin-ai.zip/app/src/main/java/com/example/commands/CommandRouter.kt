package com.example.commands

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import com.example.data.MemoryRepository
import java.net.URLEncoder

data class CommandResult(
    val isCommand: Boolean,
    val feedbackMessage: String,
    val actionName: String? = null
)

class CommandRouter(
    private val context: Context,
    private val memoryRepository: MemoryRepository
) {
    var isTorchOn = false
        private set

    fun processCommand(input: String): CommandResult {
        val lower = input.lowercase().trim()
        val nickname = memoryRepository.getUserNickname()

        // 1. YouTube & Music playback
        val isYouTubeRequest = lower.contains("youtube") ||
                lower.contains("gaana chalao") ||
                lower.contains("gana chalao") ||
                lower.contains("song chalao") ||
                lower.contains("bajao") ||
                lower.startsWith("play ")

        if (isYouTubeRequest) {
            val query = extractSongQuery(input)
            val launched = openYouTubeSearch(query)
            return if (launched) {
                CommandResult(
                    isCommand = true,
                    feedbackMessage = "$nickname, YouTube par '$query' play kar rahi hoon! 🎵",
                    actionName = "YouTube Music"
                )
            } else {
                CommandResult(
                    isCommand = true,
                    feedbackMessage = "YouTube open nahi ho paya, browser mein search kar rahi hoon.",
                    actionName = "YouTube Music"
                )
            }
        }

        // 2. WhatsApp
        if (lower.contains("whatsapp")) {
            val launched = launchAppByPackage("com.whatsapp") ||
                    launchAppByPackage("com.whatsapp.w4b") ||
                    openUrlInBrowser("https://api.whatsapp.com/")
            return CommandResult(
                isCommand = true,
                feedbackMessage = if (launched) "WhatsApp open kar diya hai, $nickname! 💬" else "WhatsApp nahi mila!",
                actionName = "WhatsApp"
            )
        }

        // 3. Chrome / Browser
        if (lower.contains("chrome") || lower.contains("browser kholo") || lower.contains("open browser")) {
            val launched = launchAppByPackage("com.android.chrome") ||
                    openUrlInBrowser("https://www.google.com")
            return CommandResult(
                isCommand = true,
                feedbackMessage = if (launched) "Browser open ho gaya, $nickname! 🌐" else "Browser launch nahi ho saka.",
                actionName = "Chrome"
            )
        }

        // 4. Camera
        if (lower.contains("camera") || lower.contains("photo khincho") || lower.contains("selfie")) {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return try {
                context.startActivity(intent)
                CommandResult(
                    isCommand = true,
                    feedbackMessage = "Camera open kar diya, pyari si smile kijiye! 📸",
                    actionName = "Camera"
                )
            } catch (_: Exception) {
                CommandResult(
                    isCommand = true,
                    feedbackMessage = "Camera app launch nahi ho paya.",
                    actionName = "Camera"
                )
            }
        }

        // 5. Calculator
        if (lower.contains("calculator") || lower.contains("hisab")) {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_APP_CALCULATOR)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return try {
                context.startActivity(intent)
                CommandResult(
                    isCommand = true,
                    feedbackMessage = "Calculator khol diya hai, $nickname! 🔢",
                    actionName = "Calculator"
                )
            } catch (_: Exception) {
                CommandResult(
                    isCommand = true,
                    feedbackMessage = "Calculator app nahi mila.",
                    actionName = "Calculator"
                )
            }
        }

        // 6. Settings
        if (lower.contains("settings") || lower.contains("setting kholo")) {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return try {
                context.startActivity(intent)
                CommandResult(
                    isCommand = true,
                    feedbackMessage = "Device settings open kar di hain! ⚙️",
                    actionName = "Settings"
                )
            } catch (_: Exception) {
                CommandResult(
                    isCommand = true,
                    feedbackMessage = "Settings launch nahi ho saki.",
                    actionName = "Settings"
                )
            }
        }

        // 7. Flashlight
        if (lower.contains("flashlight") || lower.contains("torch") || lower.contains("light")) {
            if (lower.contains("on") || lower.contains("jalao") || lower.contains("chalao")) {
                val ok = toggleFlashlight(true)
                return CommandResult(
                    isCommand = true,
                    feedbackMessage = if (ok) "Flashlight on kar di hai! 💡" else "Flashlight on nahi ho saki.",
                    actionName = "Flashlight"
                )
            } else if (lower.contains("off") || lower.contains("band")) {
                val ok = toggleFlashlight(false)
                return CommandResult(
                    isCommand = true,
                    feedbackMessage = if (ok) "Flashlight band kar di hai! 🌑" else "Flashlight band nahi ho saki.",
                    actionName = "Flashlight"
                )
            }
        }

        // 8. Set Alarm
        if (lower.contains("alarm")) {
            val hour = extractHour(lower) ?: 6
            val minute = extractMinute(lower) ?: 0
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, "Yesmin AI Alarm for $nickname")
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return try {
                context.startActivity(intent)
                CommandResult(
                    isCommand = true,
                    feedbackMessage = "$hour:${minute.toString().padStart(2, '0')} ka alarm set kar diya hai, $nickname! ⏰",
                    actionName = "Alarm"
                )
            } catch (_: Exception) {
                CommandResult(
                    isCommand = true,
                    feedbackMessage = "Alarm schedule nahi ho paya.",
                    actionName = "Alarm"
                )
            }
        }

        // 9. Quick Note
        if (lower.startsWith("save note") || lower.startsWith("note banao") || lower.startsWith("note likho")) {
            val content = input.substringAfter(" ").substringAfter(" ")
            if (content.isNotBlank()) {
                memoryRepository.addNote("Voice Note", content)
                return CommandResult(
                    isCommand = true,
                    feedbackMessage = "Note save kar liya hai: '$content' 📝",
                    actionName = "Note"
                )
            }
        }

        return CommandResult(isCommand = false, feedbackMessage = "")
    }

    private fun extractSongQuery(input: String): String {
        var clean = input.lowercase()
        val removePrefixes = listOf(
            "yesmin play ", "play ", "search youtube for ",
            "youtube par ", "gaana chalao ", "gana chalao ",
            "chalao ", "bajao "
        )
        for (prefix in removePrefixes) {
            if (clean.contains(prefix)) {
                clean = clean.substringAfter(prefix)
                break
            }
        }
        val removeSuffixes = listOf(" ke gaane", " song", " gaana", " chalao", " bajao", " play karo")
        for (suffix in removeSuffixes) {
            if (clean.endsWith(suffix)) {
                clean = clean.substringBeforeLast(suffix)
            }
        }
        return clean.trim().ifBlank { "popular songs" }
    }

    fun openYouTubeSearch(query: String): Boolean {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:results?search_query=$encoded")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(appIntent)
            true
        } catch (_: Exception) {
            openUrlInBrowser("https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, "UTF-8"))
        }
    }

    fun launchAppByPackage(packageName: String): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                true
            } else false
        } catch (_: Exception) {
            false
        }
    }

    fun openUrlInBrowser(url: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun toggleFlashlight(enable: Boolean): Boolean {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: cameraManager.cameraIdList.firstOrNull()

            if (cameraId != null) {
                cameraManager.setTorchMode(cameraId, enable)
                isTorchOn = enable
                true
            } else false
        } catch (_: Exception) {
            false
        }
    }

    private fun extractHour(text: String): Int? {
        val regex = Regex("(\\d{1,2})\\s*(am|pm|baje)?")
        val match = regex.find(text)
        if (match != null) {
            var h = match.groupValues[1].toIntOrNull() ?: return null
            val modifier = match.groupValues[2]
            if (modifier == "pm" && h < 12) h += 12
            if (modifier == "am" && h == 12) h = 0
            return h
        }
        return null
    }

    private fun extractMinute(text: String): Int? {
        val regex = Regex("\\d{1,2}:(\\d{1,2})")
        val match = regex.find(text)
        return match?.groupValues?.get(1)?.toIntOrNull()
    }
}
