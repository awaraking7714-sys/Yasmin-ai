#!/bin/bash
# ==============================================================================
# Yesmin AI — Termux Native Build Script for Android
# ==============================================================================
# This script sets up environment variables and builds the debug APK in Termux.
# Prerequisites in Termux:
#   pkg update && pkg install -y openjdk-17 gradle git clang
# ==============================================================================

set -e

echo "=== Yesmin AI Build Script for Termux ==="

# 1. Check Java Version
if ! command -v java &> /dev/null; then
    echo "[-] Java is not installed. Installing OpenJDK 17..."
    pkg install -y openjdk-17
fi

JAVA_VER=$(java -version 2>&1 | head -n 1)
echo "[+] Detected Java: $JAVA_VER"

# 2. Configure Heap / Gradle Memory for mobile devices
export GRADLE_OPTS="-Xmx1536m -XX:MaxMetaspaceSize=512m -Dorg.gradle.daemon=false"
echo "[+] Set GRADLE_OPTS for low-memory mobile compilation"

# 3. Check for ANDROID_HOME or ANDROID_SDK_ROOT
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
    echo "[!] ANDROID_HOME is not set."
    echo "    If you have installed Android Command Line Tools in Termux:"
    echo "    export ANDROID_HOME=$HOME/android-sdk"
    echo "    export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"
fi

# 4. Run Gradle Assemble
echo "[*] Starting APK compilation..."
gradle :app:assembleDebug --stacktrace --no-daemon

# 5. Locate APK
APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
    echo "=========================================================="
    echo "[SUCCESS] Yesmin AI APK successfully compiled!"
    echo "APK location: $(pwd)/$APK_PATH"
    echo ""
    echo "To install on your phone directly from Termux:"
    echo "  termux-open $APK_PATH"
    echo "or copy to internal storage:"
    echo "  cp $APK_PATH /sdcard/Download/YesminAI-debug.apk"
    echo "=========================================================="
else
    echo "[-] APK build completed but output file was not found at standard path."
fi
